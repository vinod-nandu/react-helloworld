# is-color-stop

## 1.0.0

- bump

## 1.1.0

- support calc