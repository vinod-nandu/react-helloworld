# Change log

## 1.0.1 (2018-01-03)

* Make `performance.toJSON()` return an object with `timeOrigin` property, per [clarifications from specification authors][heycam/webidl#505].

## 1.0.0 (2018-01-02)

* Initial release.

[heycam/webidl#505]: https://github.com/heycam/webidl/pull/505
