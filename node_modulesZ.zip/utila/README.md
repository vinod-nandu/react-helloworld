notareplacementforunderscore

# Installation

**npm**: `npm install utila`

**bower**: available via bower as in `bower install utila`, but you should run `npm install` before you can use it.