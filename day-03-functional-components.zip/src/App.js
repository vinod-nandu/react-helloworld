import React, { Component } from "react";

import {Footer as Foot}  from "./components/footer";
import {Header } from "./components/header";
import {Body} from "./components/body";

function App() {
  return (
    <div>
      <Header />
      <Body color="#996633"> this is the content of Body Component</Body>
      <Foot year="2010" co="Hope Tuts" />
    </div>
  );
}
export default App;
