import React from "react";

import './footer.css';

export const Footer = (props) => (
  <footer className="footer">
    <p>Copyrights &copy; -{props.year}- {props.co}</p>
  </footer>
);

export default Footer;
