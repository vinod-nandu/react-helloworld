import React from "react";

export const Body = ({ color, children }) => (
  <section style={{ color }}>{children}</section>
);
