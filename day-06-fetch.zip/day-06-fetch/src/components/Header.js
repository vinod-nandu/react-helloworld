import React from 'react';


export const Logo = () => (
  <a href="/">
    <img
      src="./him-logo.png"
      title="Himmalayaa Paints"
      alt="Himmalayaa Paints"
    />
  </a>
);
export const Header = (props) => (
    <header className="header">
    <Logo />
         <h2>-{props.subtitle}</h2>
    </header>
  );

export default Header;