import React from 'react';

const prodlist = [
  {
    prod: "INTERIOR PRIMER",
    prodqty: "1 ltr",
    stock: 25
  },
  {
    prod: "INTERIOR PRIMER",
    prodqty: "4 ltr",
    stock: 10
  },
  {
    prod: "EXTERIOR PRIMER",
    prodqty: "1 ltr",
    stock: 25
  },
  {
    prod: "EXTERIOR PRIMER",
    prodqty: "4 ltr",
    stock: 15
  },
  {
    prod: "AC WHITE",
    prodqty: "1 Kg",
    stock: 10
  },
  {
    prod: "DISTEMPER",
    prodqty: "10 ltr",
    stock: 10
  },
  {
    prod: "WALL PUTTY",
    prodqty: "1 Kg",
    stock: 10
  }

];



const prodConverter = (item, index) => (
  <tr key={index}>
    <td>{item.prod}</td>
    <td>{item.prodqty}</td>
    <td>{item.stock}</td>
  </tr>
);
const List = props => (
  <div >
    <h3>List Items:{props.title}</h3>
    <table >
      <tbody>
        <tr><th>Products</th><th>prodqty</th><th>Stock</th></tr>
        {props.items.map(props.converter)}
      </tbody>
    </table>
  </div>
);

export const Products = ({ color, children }) => (
  <section style={{ color }}>
    {children}
    <List items={prodlist} converter={prodConverter} title="Products" />
  </section>
);

