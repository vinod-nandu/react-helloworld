import React from "react";

export class GitHubApp extends React.Component {

    state = {
        users: [],
        isLoading:false,
    }

    componentDidMount() {
        let config = {

        }

        this.setState({
            isLoading: true
        });
        fetch("https://api.github.com/users", config)
        .then(res => res.json())
        .then(res => this.setState({ users: res, isLoading: false }))
    }

    toUserUI = (user) => (<div key={user.id}>
        <img className="avatar" src={user.avatar_url} alt={user.login}></img>
        <span>{user.login}</span>
    </div>)

    render() {
        if(this.state.isLoading) {
            return <div>Loading. Please wait...!</div>
        }
        return (<div>
            <h2>github users</h2>
            <div>
                {
                    this.state.users.map(this.toUserUI)
                }
            </div>
        </div>)
    }
}