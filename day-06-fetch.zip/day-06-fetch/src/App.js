import React from 'react';

import './App.css';
import Header  from './components/Header';
import {Products}  from './components/Products';
import { GitHubApp } from './github';

function App() {
  return (
   
    <div className="App">
     <Header subtitle="Products" />

     <GitHubApp />
     <div className="prodTbl">
      <Products  color="#282c34" />
      </div>

      
    </div>
  );
}



export default App; 
