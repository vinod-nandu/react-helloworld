import React from "react";

import "./footer.css";
/* 
export const Footer = (props) => (
  <footer className="footer">
    <p>Copyrights &copy; -{props.year}- {props.co}</p>
  </footer>
);
*/

export class Footer extends React.Component {
  render() {
    return (
      <footer className="footer">
        <p>
          Copyrights &copy; -{this.props.year}- {this.props.co}
        </p>
      </footer>
    );
  }
}
export default Footer;
