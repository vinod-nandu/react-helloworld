import React from "react";

import "./header.css";

export const Logo = () => (
  <a href="/">
    <img
      src="./Hope-Tutors-final-logo.png"
      title="Hope Tutors Logo"
      alt="Hope Tutors Logo"
    />
  </a>
);

export const Header = () => (
  <header className="header">
    <h1>
      <Logo />
      This is React App!!
    </h1>
  </header>
);

export default Header;
