import React from "react";
import "./body.css";

const courses = [
  {
    name: "ReactJS",
    cost: 12000
  },
  {
    name: "Angulat",
    cost: 15000
  },
  {
    name: "VueJS",
    cost: 10000
  },
  {
    name: "DOJO",
    cost: 14000
  }
];

const staffs = [
  {
    name: "Jagan",
    role: "Trainer"
  },
  {
    name: "Murali",
    role: "Coordinator"
  },
  {
    name: "Some one",
    role: "some thing"
  }
];

const Course = ({ name, cost }) => {
  return (
    <div>
      <span>{name}</span>
      <span> - </span>
      <span>₹ </span>
      <span>{cost}</span>
      <span>/-</span>
    </div>
  );
};

const courseConverter = item => {
  return <Course key={item.name} name={item.name} cost={item.cost} />;
};

const staffConverter = item => (
  <div>
    <label>Name:</label> <span>{item.name}</span>
    <hr />
    <label>Role:</label> <span>{item.role}</span>
  </div>
);

const List = props => (
  <div className="my-list">
  <h3>List Items:{props.title}</h3>
  {props.items.map(props.converter)}
  </div>
);

export const Body = ({ color, children }) => (
  <section style={{ color }}>
    {children}
    {/* <div className="my-list">
      {courses.map(courseConverter)}
    </div>
 */}
    <List items={courses} converter={courseConverter} title="Course" />
    <List items={staffs} converter={staffConverter} title="Staff" />
    {/* <div className="my-list">
      {staffs.map(staffConverter)}
    </div> */}
  </section>
);
