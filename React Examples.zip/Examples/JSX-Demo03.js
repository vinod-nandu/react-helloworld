import React, { Component } from 'react';
import './App.css';

class App extends Component {
  render() {
    return (
	  React.createElement('div',null,React.createElement('p', null, 'React Component'))
	 
	);
  }
}

export default App;
