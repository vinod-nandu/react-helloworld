export default {
    CSSDemo_CSSInJS: {
        margin: '40px',
        border: '5px dashed blue'
    },
    CSSDemo_Content_CSSInJS: {
        fontSize: '15px',
        textAlign: 'center',
        backgroundColor: 'lightgray'
    }
	}