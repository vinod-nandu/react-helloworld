import React from 'react';

const user = (props) => {
    return <p>{props.userName}</p>
}

export default user