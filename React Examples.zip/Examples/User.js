import React from 'react';

const user = () => {
    const userName = 'Lakshman';
	const alignValue = 'right';
    return <p align={alignValue}>{userName}</p>
}

export default user