var querystring = require("querystring");
module.exports = querystring;