var inspector = {};
try { inspector = require("inspector"); } catch (e) { }
module.exports = inspector;