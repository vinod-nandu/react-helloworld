var perf_hooks = {};
try { perf_hooks = require("perf_hooks"); } catch (e) { }
module.exports = perf_hooks;