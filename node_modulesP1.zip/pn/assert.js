var assert = require("assert");
module.exports = assert;