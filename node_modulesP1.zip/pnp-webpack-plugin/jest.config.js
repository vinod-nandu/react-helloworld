module.exports = {
    resolver: require.resolve(`jest-pnp-resolver`),
    testEnvironment: `node`,
};
