import React from "react";
import "./viewstack.css";

export class TabNavigator extends React.Component {

    state = {
        index: this.props.index || 0
    }

  renderChild = (child, index) => {
    let viewClassName = "view";
    if (index === this.state.index) {
      viewClassName += " show";
    } else {
      viewClassName += " hide";
    }
    if (this.props.selectedViewClass) {
      viewClassName += " " + this.props.selectedViewClass;
    }
    return (
      <div className={viewClassName} key={index}>
        {child}
      </div>
    );
  };

  renderTab = (child, index) => {
    let title = child.props.title || `Tab ${index+1}`;

    return (<button onClick={e=>this.onTabClick(index)}>{title}</button>);
  };

  onTabClick = index => {
      this.setState({
          index
      });
  }

  render() {
    return (
      <div className="view-stack">
        <header className="tab-holder">
        {React.Children.map(this.props.children, this.renderTab)}
        </header>
        <section className="view-holder">
          {React.Children.map(this.props.children, this.renderChild)}
        </section>
      </div>
    );
  }
}
