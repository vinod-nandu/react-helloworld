# mississippi Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## 3.0.0 - 2018-02-26
* Update to pump@3.0.0.  Returns the last stream the pipeline to enable chaining.  (Use the individual modules to avoid potentially unnecessary major updates in your project).

## 2.0.0 - 2018-01-30
* Update to pump@2.0.1.  (Use the individual modules to avoid potentially unnecessary major updates in your project)
* Pin engines support to >= Node 4.0.0.  Run Node LTS or greater.
