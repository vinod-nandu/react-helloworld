import React from 'react';

class employee extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        const empCard = {
            width: '150px',
            border: '2px solid black',
            borderRadius: '4px',
            marginLeft: '15px',
            padding: '12px'
        }
        return (
            <div style={empCard}>
                <h3>{this.props.name}</h3>
                <h3>{this.props.email}</h3>
            </div>
        )
    }

}

export default employee;