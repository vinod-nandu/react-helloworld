import React from 'react';
import PropTypes from 'prop-types';

const user = (props) =>{
    // const userName = 'Srinivas';
    // const alignValue = 'right';
    return <div>
        <p>{props.userName}</p>
        <p>{props.children}</p>
        </div>
}

user.propTypes = {
    // userName : PropTypes.number
    userName : PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number
    ])
}

export default user;