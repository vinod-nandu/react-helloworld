import React, { Component } from 'react';
import './App.css';
import Employee from './employee';

class App extends Component {
    state = {
      Employees : [
        {id:101, name:'Srinivas', email:'Srinivas@gmail.com'},
        {id:102, name:'Srini', email:'Srini@gmail.com'}
      ]
    }

  render() {
    return (
       <div className='App'>
      {this.state.Employees.map(employee =>{
        return (<Employee name={employee.name}
        email={employee.email} key={employee.id}
        ></Employee>)
      })}
      </div> 
      
    );
  }
}

export default App;
