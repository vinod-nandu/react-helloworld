import React from 'react';

class userContainer extends React.Component{
    state = {
        Users : [
            {name : 'Srinivas'}
        ]
    }

    render(){ 
        return(
            <div>
                <p>{this.state.Users[0].name}</p>
                <button onClick={this.clickHandler}>Click</button>
            </div>
        )
    }

    clickHandler = (e)=>{//e is a synthatic event

        this.setState({
            Users : [
                {name : 'Srini'}
            ]
        })
    }
}

export default userContainer