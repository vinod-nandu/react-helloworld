v2.1.0 - Mon, 19 Sep 2016 21:55:22 GMT
--------------------------------------

- 


v2.0.0 - Wed, 06 Apr 2016 04:31:02 GMT
--------------------------------------

- 


v1.3.0 - Wed, 14 Oct 2015 14:35:55 GMT
--------------------------------------

- [45abf8fde380d7b1f5dc0e798d435ed50b834d9c](../../commit/45abf8fde380d7b1f5dc0e798d435ed50b834d9c) [added] added custom matcher function to determine whether to ignore a file
- [eebc91c67abce413d6213e8f389ba4e0d32ffb63](../../commit/eebc91c67abce413d6213e8f389ba4e0d32ffb63) [fixed] allow ignoring directories

v1.2.1 - Wed, 14 Jan 2015 16:49:55 GMT
--------------------------------------

- 


