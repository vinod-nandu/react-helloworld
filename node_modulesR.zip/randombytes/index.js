module.exports = require('crypto').randomBytes
