const set = require('regenerate')(0xA95F);
set.addRange(0xA930, 0xA953);
module.exports = set;
