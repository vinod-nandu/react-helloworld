const set = require('regenerate')();
set.addRange(0x11180, 0x111CD).addRange(0x111D0, 0x111DF);
module.exports = set;
