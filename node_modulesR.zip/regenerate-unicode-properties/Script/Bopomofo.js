const set = require('regenerate')();
set.addRange(0x2EA, 0x2EB).addRange(0x3105, 0x312F).addRange(0x31A0, 0x31BA);
module.exports = set;
