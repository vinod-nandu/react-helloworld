const set = require('regenerate')();
set.addRange(0x780, 0x7B1);
module.exports = set;
