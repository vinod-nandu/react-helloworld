const set = require('regenerate')();
set.addRange(0x110D0, 0x110E8).addRange(0x110F0, 0x110F9);
module.exports = set;
