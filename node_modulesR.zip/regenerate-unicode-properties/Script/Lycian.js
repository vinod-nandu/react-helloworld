const set = require('regenerate')();
set.addRange(0x10280, 0x1029C);
module.exports = set;
