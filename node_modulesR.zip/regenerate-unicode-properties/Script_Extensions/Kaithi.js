const set = require('regenerate')(0x110CD);
set.addRange(0x966, 0x96F).addRange(0xA830, 0xA839).addRange(0x11080, 0x110C1);
module.exports = set;
