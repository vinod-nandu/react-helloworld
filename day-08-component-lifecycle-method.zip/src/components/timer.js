import React, { Component } from "react";

export default class Timer extends Component {
  state = {
    hh: 0,
    mm: 0,
    ss: 0
  };
  componentDidMount() {
    this.timer = setInterval(this.updateTime, 200);
  }

  componentWillUnmount() {
    clearInterval(this.timer);
  }

  shouldComponentUpdate(nextProps, nextState) {
      if(this.state.ss !== nextState.ss) {
          return true;
      }
      return false;
  }

  componentDidUpdate(prevProps, prevState) {
    if(this.state.ss !== prevState.ss) {
        console.log(this.state.ss, " seconds");
    }
  }

  updateTime = () => {
    let d = new Date();
    this.setState({
      hh: d.getHours(),
      mm: d.getMinutes(),
      ss: d.getSeconds()
    });
  };

  render() {
    let { hh, mm, ss } = this.state;
    return (
      <div>
        <span>{hh}</span>:<span>{mm}</span>:<span>{ss}</span>
      </div>
    );
  }
}
