import React from "react";
import "./list.css";
export class List extends React.Component {
  onItemClick = e => {
    let index = Number(e.currentTarget.attributes.index.value);
    let item = this.props.items[index];
    this.props.onSelect && this.props.onSelect(item);
/* 
    if(this.props.onSelect) {
      this.props.onSelect(item);
    }
     */
  };

  localRederer = (item, index) => {
    return (
      <div
        className="my-list-item"
        key={index}
        index={index}
        title={this.props.title}
        onClick={this.onItemClick}
      >
        {this.props.converter(item)}
      </div>
    );
  };
  render() {
    return (
      <div className="my-list">
        <h3>List Items:{this.props.title}</h3>
        {this.props.items.map(this.localRederer)}
      </div>
    );
  }
}
