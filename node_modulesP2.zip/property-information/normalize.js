'use strict'

module.exports = normalize

function normalize(value) {
  return value.toLowerCase()
}
