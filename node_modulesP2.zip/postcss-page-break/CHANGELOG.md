# Change Log
This project adheres to [Semantic Versioning](http://semver.org/).

## 2.0
* Updated: Support for PostCSS v7+
* Updated: Support for Node v6+

## 1.0
* Initial release
