2.0.0 / 2018-08-09
=================
  * [Breaking] throw when `iterable` is nullish
  * [Docs] Fix link to proposed spec

1.0.0 / 2018-03-21
=================
  * v1.0.0
