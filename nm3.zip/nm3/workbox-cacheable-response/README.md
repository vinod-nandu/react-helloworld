This module's documentation can be found at https://developers.google.com/web/tools/workbox/modules/workbox-cacheable-response
