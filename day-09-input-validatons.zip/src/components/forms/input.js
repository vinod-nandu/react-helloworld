import React, { Component } from "react";

export default class Input extends Component {
  state = {
    errMsg: null
  };

  onChange = e => {
    this.props.onChange && this.props.onChange(e);
  };

  onBlur = e => {
    let errMsg = this.getErrorMsg(e.target.value);
    this.setState({
      errMsg
    });
  };

  getErrorMsg = value => {
      let {
          minLength=false,
          maxLength=false,
          required=false,
          regex=false
      } = this.props;
      let len = value.length;

      if(required) {
          if(len === 0) {
              return "this field is required";
          }
      }
      if(minLength !== false) {
        if (len < minLength) {
            return `should be minmum ${minLength} chars!`; 
        }
      }
      if(maxLength !== false) {
          if(len > maxLength) {
            return `only ${maxLength} chars allowed!`; 
          }
      }
      if(regex !== false) {
          if(false === regex.test(value)) {
                return "should not contain invalid chars";
          }
      }
  }

  render() {
    let { defaultValue, placeholder, type="text" } = this.props;
    return (
      <div className="input">
        <input
          type={type}
          defaultValue={defaultValue}
          placeholder={placeholder}
          onChange={this.onChange}
          onBlur={this.onBlur}
        />
        <div style={error}>{this.state.errMsg}</div>
      </div>
    );
  }
}

const error = {
    color: "red",
    fontSize: "small"
}