import React from "react";
import "./viewstack.css";
import ErrorBoundary from "./error-boundary";

export class TabNavigator extends React.Component {
  state = {
    index: this.props.index || 0,
    hasError: false
  };

  renderChild = (child, index) => {
    let viewClassName = "view";
    if (index === this.state.index) {
      viewClassName += " show";
    } else {
      viewClassName += " hide";
    }
    if (this.props.selectedViewClass) {
      viewClassName += " " + this.props.selectedViewClass;
    }
    return (
      <div className={viewClassName} key={index}>
        <ErrorBoundary>{child}</ErrorBoundary>
      </div>
    );
  };

  renderTab = (child, index) => {
    let title = child.props.title || `Tab ${index + 1}`;

    return <button onClick={e => this.onTabClick(index)}>{title}</button>;
  };

  onTabClick = index => {
    this.setState({
      index
    });
  };

  render() {
    return (
      <ErrorBoundary>
        <div className="view-stack">
          <header className="tab-holder">
            {React.Children.map(this.props.children, this.renderTab)}
          </header>
          <section className="view-holder">
            {React.Children.map(this.props.children, this.renderChild)}
          </section>
        </div>
      </ErrorBoundary>
    );
  }
}
