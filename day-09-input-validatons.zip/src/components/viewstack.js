import React from "react";
import "./viewstack.css";

export class ViewStack extends React.Component {
  renderChild = (child, index) => {
      let viewClassName = "view";
      if(index === this.props.index) {
          viewClassName += " show";
      } else {
        viewClassName += " hide";
      }
      if(this.props.selectedViewClass) {
          viewClassName +=  " " + this.props.selectedViewClass;
      }
    return <div className={viewClassName} key={index}>{child}</div>;
  };

  render() {
    return (
      <div className="view-stack">
        {React.Children.map(this.props.children, this.renderChild)}
      </div>
    );
  }
}
