import React, { Component } from "react";

export default class ErrorBoundary extends Component {
    state = {
        hasError: false,
        err: null,
        info: null
    }
    
    componentDidCatch(err, info) {
        console.log({err, info});
  
        this.setState({
          hasError: true,
          err, info
        });
      }
  
  render() {
      if(this.state.hasError) {
        return (
            <div>
              <div style={{ color: "red" }}>some thing went wrong!!</div>
            </div>
          );
      }
      return this.props.children;
    
  }
}
