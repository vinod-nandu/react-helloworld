import React, { Component } from "react";

import { Footer } from "./components/footer";
import { Header } from "./components/header";
import { Body } from "./components/body";
import { ViewStack } from "./components/viewstack";
import { TabNavigator } from "./components/tab-navigator";
import Timer from "./components/timer";
import Input from "./components/forms/input";

class App extends Component {
  getCompanyName = () => {
    return "Hope Tutors Inc";
  };

  login = {
    userName: "Hope"
  };

  state = {
    selectedViewIndex: 0
  };

  changeView = e => {
    this.setState({
      selectedViewIndex: e.target.value - 1
    });
  };

  render() {
    console.log(this.login);
    return (
      <div>
        <Header data={this.login} />

        <Body color="#996633">
          <select onChange={this.changeView}>
            <option value={1}>Show View #1</option>
            <option value={2}>Show View #2</option>
            <option value={3}>Show View #3</option>
            <option value={4}>Show View #4</option>
            <option value={5}>Show View #5</option>
            <option value={6}>Show View #6</option>
            <option value={7}>Show View #7</option>
          </select>
          <ViewStack index={this.state.selectedViewIndex}>
            <div>
              this is div 1 <Timer />
              <Input placeholder="all validation" minLength={3} maxLength={6} required regex={/^[a-z]+$/i} />
              <Input placeholder="max, req, reg" maxLength={6} required regex={/^[a-z]+$/i} />
              <Input placeholder="req, reg" required regex={/^[a-z]+$/i} />
              <Input placeholder="reg" regex={/^[a-z]+$/i} />
              <Input placeholder="none" />
              <Input type="password" placeholder="enter password" />
              <Input type="date" />
              <Input type="email" ></Input>
            </div>
            <div>this is div 2</div>
            <Header data={this.login} />
            <div>this is div 3</div>
            <Header data={this.login} />
            <div>this is div 4</div>
            <h2>this is h2</h2>
          </ViewStack>
          <hr />
          <TabNavigator
            index={this.state.selectedViewIndex}
            selectedViewClass="my-view"
          >
            <div title="div 1">this is div 1</div>
            <div title="div 2">
              this is div 2
            </div>
            <Header title="header 1" data={this.login} />
            <div>this is div 3</div>
            <Header data={this.login} />
            <div>this is div 4</div>
            <h2 title="h2">this is h2</h2>
          </TabNavigator>
        </Body>
        <Footer year={2019} getName={this.getCompanyName} />
      </div>
    );
  }
}

const BuggyComponent = () => {
  return {};
};

export default App;
