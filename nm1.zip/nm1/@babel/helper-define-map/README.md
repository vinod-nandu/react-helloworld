# @babel/helper-define-map

> Helper function to define a map

See our website [@babel/helper-define-map](https://babeljs.io/docs/en/next/babel-helper-define-map.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/helper-define-map
```

or using yarn:

```sh
yarn add @babel/helper-define-map --dev
```
